
const byId = (id) => document.getElementById(id);

const esc = (value) =>
  String(value).replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));

// Мобильді мәзір
function setupMenu() {
  const toggle = byId('menuToggle');
  const menu = byId('mobileNav');

  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const open = menu.classList.toggle('show');
      toggle.setAttribute('aria-expanded', String(open));
    });
  }
}

// Зат карточкасын жасау
function card(item) {
  return `
    <article class="item-card">
      <div class="item-art" role="img" aria-label="${esc(item.name)}">
        ${item.emoji}
      </div>
      <div class="item-body">
        <span class="pill">${esc(item.category)}</span>
        <h3>${esc(item.name)}</h3>
        <p class="item-meta">📍 ${esc(item.city)}</p>
        <div class="item-row">
          <span class="free">Тегін</span>
          <button class="btn btn-outline" type="button" data-item="${item.id}">
            Толығырақ
          </button>
        </div>
      </div>
    </article>
  `;
}

// Зат туралы толық ақпарат
function setupModal() {
  const modal = byId('itemModal');
  if (!modal) return;

  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-item]');

    if (btn) {
      const item = ITEMS.find(i => i.id === Number(btn.dataset.item));
      if (!item) return;

      byId('modalContent').innerHTML = `
        <div class="item-art" role="img" aria-label="${esc(item.name)}">
          ${item.emoji}
        </div>
        <span class="pill">${esc(item.category)}</span>
        <h2>${esc(item.name)}</h2>
        <p>📍 ${esc(item.city)} · <strong>Тегін</strong></p>
        <p>${esc(item.description)}</p>
        <button type="button" class="btn btn-primary" id="requestDemo">
          Алуды сұрау
        </button>
        <p class="muted-note">
          Бұл демонстрациялық нұсқа. Өтінімді серверге жіберу
          келесі кезеңде іске асырылады.
        </p>
      `;

      modal.classList.add('show');
      byId('modalClose').focus();
    }

    if (e.target.id === 'requestDemo') {
      alert('Бұл функция сервермен және дерекқормен қосылған соң іске қосылады.');
    }

    if (e.target === modal || e.target.id === 'modalClose') {
      modal.classList.remove('show');
    }
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') modal.classList.remove('show');
  });
}

// Басты беттегі заттар
function setupHome() {
  const el = byId('featuredItems');

  if (el) {
    el.innerHTML = ITEMS.slice(0, 3).map(card).join('');
  }
}

// Каталогтағы іздеу және сүзу
function setupCatalog() {
  const el = byId('catalogItems');
  if (!el) return;

  const search = byId('searchInput');
  const category = byId('categoryFilter');
  const city = byId('cityFilter');
  const count = byId('itemCount');

  const initial = new URLSearchParams(location.search).get('q');
  if (initial) search.value = initial;

  function draw() {
    const q = search.value.toLocaleLowerCase('kk').trim();

    const list = ITEMS.filter(i =>
      i.name.toLocaleLowerCase('kk').includes(q) &&
      (category.value === 'all' || category.value === i.category) &&
      (city.value === 'all' || city.value === i.city)
    );

    el.innerHTML = list.length
      ? list.map(card).join('')
      : '<div class="empty">Сұранысыңызға сәйкес зат табылмады. Басқа сүзгіні қолданып көріңіз.</div>';

    count.textContent = `${list.length} зат табылды`;
  }

  [search, category, city].forEach(el =>
    el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', draw)
  );

  draw();
}

// Форма хабарламаларын көрсету
function showMessage(form, msg, isError = false) {
  const box = form.querySelector('.form-message');

  box.textContent = msg;
  box.className = 'form-message notice' + (isError ? ' error' : '');
  box.hidden = false;
}

// Тіркелу және кіру формаларын тексеру
function setupForms() {
  const reg = byId('registerForm');
  const login = byId('loginForm');

  if (reg) {
    reg.addEventListener('submit', e => {
      e.preventDefault();

      if (!reg.reportValidity()) return;

      const pw = byId('password').value;
      const confirm = byId('confirmPassword').value;

      if (pw.length < 8) {
        return showMessage(
          reg,
          'Құпия сөз кемінде 8 таңбадан тұруы керек.',
          true
        );
      }

      if (pw !== confirm) {
        return showMessage(
          reg,
          'Құпия сөздер сәйкес келмейді.',
          true
        );
      }

      showMessage(
        reg,
        'Форма дұрыс толтырылды! Бұл тек frontend үлгісі: аккаунт жасалмады және деректер сақталмады.'
      );

      reg.reset();
    });
  }

  if (login) {
    login.addEventListener('submit', e => {
      e.preventDefault();

      if (!login.reportValidity()) return;

      showMessage(
        login,
        'Деректер форматы дұрыс. Нақты жүйеге кіру үшін PHP/MySQL серверін қосу қажет.'
      );
    });
  }
}

// Барлық функцияларды іске қосу
document.addEventListener('DOMContentLoaded', () => {
  setupMenu();
  setupHome();
  setupCatalog();
  setupModal();
  setupForms();
});
