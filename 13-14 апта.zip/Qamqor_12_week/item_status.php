<?php
require_once 'includes/auth.php'; require_login(); require_once 'config/database.php'; require_once 'includes/csrf.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Әдіс рұқсат етілмейді.');}
verify_csrf();$id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);if(!$id){http_response_code(400);exit('Зат ID дұрыс емес.');}
$pdo->beginTransaction();
try{
 $q=$pdo->prepare("UPDATE items SET status='given' WHERE id=? AND user_id=? AND status IN ('available','reserved')");$q->execute([$id,$_SESSION['user_id']]);
 if($q->rowCount()){$u=$pdo->prepare("UPDATE item_requests SET status='completed' WHERE item_id=? AND status='accepted'");$u->execute([$id]);}
 $pdo->commit();header('Location: my_items.php?status_updated='.($q->rowCount()?1:0));exit;
}catch(Throwable $e){$pdo->rollBack();throw $e;}
