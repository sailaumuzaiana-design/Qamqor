<?php
require_once 'includes/auth.php';
require_login();
$pageTitle = 'Жеке кабинет';
require_once 'includes/header.php';
?>
<section class="container dashboard">
 <div class="eyebrow">QAMQOR ҚАУЫМДАСТЫҒЫ</div>
 <h1>Қош келдіңіз, <?= e($_SESSION['user_name'] ?? 'пайдаланушы') ?>!</h1>
 <p class="muted">Сіз жүйеге сәтті кірдіңіз. Бұл бет тек тіркелген пайдаланушыларға қолжетімді.</p>
 <div class="dashboard-panel"><div><h2>Жақсылық жасауға дайынсыз ба?</h2><p>Каталогтан тегін заттарды қарап, өзіңізге қажет дүниені табыңыз.</p></div><div class="dashboard-actions"><a class="btn btn-primary" href="catalog.php">Каталогты ашу →</a><a class="btn btn-light" href="my_items.php">Менің заттарым</a><a class="btn btn-light" href="item_create.php">+ Жаңа зат қосу</a></div></div>
 <a class="text-link" href="logout.php">Аккаунттан шығу</a>
</section>
<?php require_once 'includes/footer.php'; ?>
