<?php
require_once 'includes/auth.php'; require_login(); require_once 'config/database.php'; require_once 'includes/csrf.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Бұл әрекетке POST сұранысы қажет.');}
verify_csrf();$id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);if(!$id){http_response_code(400);exit('Жарияланым ID дұрыс емес.');}
$stmt=$pdo->prepare('DELETE FROM items WHERE id=:id AND user_id=:user_id');$stmt->execute(['id'=>$id,'user_id'=>$_SESSION['user_id']]);header('Location: my_items.php?deleted=' . ($stmt->rowCount()?1:0));exit;
