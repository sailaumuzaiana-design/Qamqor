USE qamqor;

-- Қолданыстағы users кестесіне рөл бағанын қосу.
ALTER TABLE users ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user';

-- Жарияланымдарға пікірлер кестесі.
CREATE TABLE IF NOT EXISTS comments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  item_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  comment_text VARCHAR(1000) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_comments_item FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
  CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_comments_item_created (item_id, created_at)
) ENGINE=InnoDB;

-- Әкімші рөлін тағайындау үшін төмендегі сұранысты орындаңыз.
-- Электрондық поштаны өз әкімші аккаунтыңыздың поштасына ауыстырыңыз:
-- UPDATE users SET role='admin' WHERE email='your-email@example.com';
