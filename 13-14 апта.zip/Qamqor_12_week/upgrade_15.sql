USE qamqor;

-- Жарияланымның ағымдағы күйі.
ALTER TABLE items
  ADD COLUMN status ENUM('available','reserved','given') NOT NULL DEFAULT 'available';

-- Затты алуға жіберілген өтініштер.
CREATE TABLE IF NOT EXISTS item_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  item_id INT UNSIGNED NOT NULL,
  requester_id INT UNSIGNED NOT NULL,
  message VARCHAR(1000) NOT NULL,
  status ENUM('pending','accepted','rejected','completed','cancelled') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_item_requests_item FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
  CONSTRAINT fk_item_requests_user FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_item_request_user (item_id, requester_id),
  INDEX idx_item_requests_owner_status (item_id, status)
) ENGINE=InnoDB;
