<?php
require_once 'includes/auth.php';
require_once 'config/database.php';

$pageTitle = 'Заттар каталогы';
$q = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$city = trim($_GET['city'] ?? '');
$dateFrom = trim($_GET['date_from'] ?? '');
$dateTo = trim($_GET['date_to'] ?? '');
$sort = $_GET['sort'] ?? 'date_desc';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 6;

$categories = ['Киім', 'Кітап', 'Балалар заттары', 'Тұрмыстық заттар'];
$sortOptions = [
    'date_desc' => 'i.created_at DESC, i.id DESC',
    'date_asc' => 'i.created_at ASC, i.id ASC',
    'title_asc' => 'i.title ASC',
    'title_desc' => 'i.title DESC'
];

if (!in_array($category, $categories, true)) $category = '';
if (!array_key_exists($sort, $sortOptions)) $sort = 'date_desc';

function valid_date_value($value) {
    if ($value === '') return true;
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    return $date && $date->format('Y-m-d') === $value;
}
if (!valid_date_value($dateFrom)) $dateFrom = '';
if (!valid_date_value($dateTo)) $dateTo = '';
if ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo) {
    $temp = $dateFrom; $dateFrom = $dateTo; $dateTo = $temp;
}

/*
 * Барлық сүзгі мәндері positional placeholder (?) арқылы беріледі.
 * Бұл PDO-ның әртүрлі MySQL баптауларында іздеу параметрлерінің
 * дұрыс байланысуын қамтамасыз етеді.
 */
$where = [];
$params = [];

if ($q !== '') {
    $where[] = '(i.title LIKE ? OR i.description LIKE ? OR i.city LIKE ? OR i.category LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
if ($category !== '') {
    $where[] = 'i.category = ?';
    $params[] = $category;
}
if ($city !== '') {
    $where[] = 'i.city LIKE ?';
    $params[] = '%' . $city . '%';
}
if ($dateFrom !== '') {
    $where[] = 'i.created_at >= ?';
    $params[] = $dateFrom . ' 00:00:00';
}
if ($dateTo !== '') {
    $where[] = 'i.created_at <= ?';
    $params[] = $dateTo . ' 23:59:59';
}

$where[] = "i.status = 'available'";
$whereSql = 'WHERE ' . implode(' AND ', $where);
$orderBy = $sortOptions[$sort];

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM items i $whereSql");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$sql = "SELECT i.id, i.title, i.category, i.city, i.description, i.icon, i.created_at, u.full_name
        FROM items i
        INNER JOIN users u ON u.id = i.user_id
        $whereSql
        ORDER BY $orderBy
        LIMIT ? OFFSET ?";
$stmt = $pdo->prepare($sql);
$index = 1;
foreach ($params as $value) {
    $stmt->bindValue($index++, $value, PDO::PARAM_STR);
}
$stmt->bindValue($index++, $perPage, PDO::PARAM_INT);
$stmt->bindValue($index, $offset, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll();

$query = $_GET;
unset($query['page']);
function page_url($pageNumber, $queryParams) {
    $queryParams['page'] = $pageNumber;
    return 'catalog.php?' . http_build_query($queryParams);
}

require_once 'includes/header.php';
?>
<section class="container catalog-page">
    <div class="eyebrow">ҚАМҚОРЛЫҚ КАТАЛОГЫ</div>
    <div class="section-head">
        <div>
            <h1>Өзіңізге қажет затты табыңыз</h1>
            <p class="muted">Заттың атауын жазып іздеңіз немесе төмендегі сүзгілерді қолданыңыз.</p>
        </div>
        <?php if (is_logged_in()): ?>
            <a class="btn btn-primary" href="item_create.php">+ Зат қосу</a>
        <?php endif; ?>
    </div>

    <form class="filter-bar advanced-filter" method="get" action="catalog.php">
        <label>Затты іздеу
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="Мысалы: кітап, күртеше..." autocomplete="off">
        </label>
        <label>Санат
            <select name="category">
                <option value="">Барлық санаттар</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= e($c) ?>" <?= $category === $c ? 'selected' : '' ?>><?= e($c) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Қала
            <input type="text" name="city" value="<?= e($city) ?>" placeholder="Қала атауы">
        </label>
        <label>Күнінен бастап
            <input type="date" name="date_from" value="<?= e($dateFrom) ?>">
        </label>
        <label>Күніне дейін
            <input type="date" name="date_to" value="<?= e($dateTo) ?>">
        </label>
        <label>Күні бойынша сұрыптау
            <select name="sort">
                <option value="date_desc" <?= $sort === 'date_desc' ? 'selected' : '' ?>>Алдымен жаңалары</option>
                <option value="date_asc" <?= $sort === 'date_asc' ? 'selected' : '' ?>>Алдымен ескілері</option>
                <option value="title_asc" <?= $sort === 'title_asc' ? 'selected' : '' ?>>Атауы: А–Я</option>
                <option value="title_desc" <?= $sort === 'title_desc' ? 'selected' : '' ?>>Атауы: Я–А</option>
            </select>
        </label>
        <button class="btn btn-primary filter-btn" type="submit">Іздеу</button>
        <a class="btn btn-light filter-btn" href="catalog.php">Тазалау</a>
    </form>

    <div class="results-line">
        <span>Табылған зат саны: <?= $total ?> · Бет: <?= $page ?>/<?= $totalPages ?></span>
        <?php if ($q !== ''): ?><span>Іздеу сөзі: «<?= e($q) ?>»</span><?php endif; ?>
    </div>

    <?php if ($items): ?>
        <div class="item-grid">
            <?php foreach ($items as $item): ?>
                <article class="item-card">
                    <div class="item-art mint"><?= e($item['icon']) ?></div>
                    <div class="item-info">
                        <span class="tag"><?= e($item['category']) ?></span>
                        <h3><?= e($item['title']) ?></h3>
                        <p>📍 <?= e($item['city']) ?></p>
                        <p><?= e(mb_strimwidth($item['description'] ?? '', 0, 110, '…', 'UTF-8')) ?></p>
                        <div class="item-foot">
                            <b>Тегін</b>
                            <a class="btn btn-outline" href="item_view.php?id=<?= (int)$item['id'] ?>">Толығырақ</a>
                        </div>
                        <small class="muted">Жарияланған күні: <?= e(date('d.m.Y', strtotime($item['created_at']))) ?></small>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav class="pagination" aria-label="Беттер">
                <?php if ($page > 1): ?><a href="<?= e(page_url($page - 1, $query)) ?>">← Алдыңғы</a><?php endif; ?>
                <?php for ($n = max(1, $page - 2); $n <= min($totalPages, $page + 2); $n++): ?>
                    <a class="<?= $n === $page ? 'active' : '' ?>" href="<?= e(page_url($n, $query)) ?>"><?= $n ?></a>
                <?php endfor; ?>
                <?php if ($page < $totalPages): ?><a href="<?= e(page_url($page + 1, $query)) ?>">Келесі →</a><?php endif; ?>
            </nav>
        <?php endif; ?>
    <?php else: ?>
        <div class="empty">
            <?php if ($q !== '' || $category !== '' || $city !== '' || $dateFrom !== '' || $dateTo !== ''): ?>
                Іздеу бойынша зат табылмады. Сөздің жазылуын тексеріңіз немесе сүзгілерді өзгертіңіз.
            <?php else: ?>
                Әзірге жарияланған зат жоқ.
            <?php endif; ?>
        </div>
    <?php endif; ?>
</section>
<?php require_once 'includes/footer.php'; ?>
