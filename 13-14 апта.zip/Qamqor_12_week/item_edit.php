<?php
require_once 'includes/auth.php'; require_login(); require_once 'config/database.php'; require_once 'includes/csrf.php';
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT); if(!$id){http_response_code(400);exit('Жарияланым ID дұрыс емес.');}
$stmt=$pdo->prepare('SELECT * FROM items WHERE id=:id AND user_id=:user_id'); $stmt->execute(['id'=>$id,'user_id'=>$_SESSION['user_id']]); $item=$stmt->fetch();
if(!$item){http_response_code(404);exit('Жарияланым табылмады немесе оны өңдеуге құқығыңыз жоқ.');}
$categories=['Киім','Кітап','Балалар заттары','Тұрмыстық заттар']; $icons=['📦','🧥','📚','🧸','💡','🎒','✏️']; $errors=[];
$title=$item['title'];$category=$item['category'];$city=$item['city'];$description=$item['description'];$icon=$item['icon'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $title=trim($_POST['title']??'');$category=trim($_POST['category']??'');$city=trim($_POST['city']??'');$description=trim($_POST['description']??'');$icon=trim($_POST['icon']??'📦');
 if(mb_strlen($title)<2||mb_strlen($title)>150)$errors[]='Зат атауы 2–150 таңба аралығында болуы керек.';
 if(!in_array($category,$categories,true))$errors[]='Санатты таңдаңыз.';
 if(mb_strlen($city)<2||mb_strlen($city)>100)$errors[]='Қаланы дұрыс енгізіңіз.';
 if(mb_strlen($description)>2000)$errors[]='Сипаттама 2000 таңбадан аспауы керек.';
 if(!in_array($icon,$icons,true))$icon='📦';
 if(!$errors){$up=$pdo->prepare('UPDATE items SET title=:title,category=:category,city=:city,description=:description,icon=:icon WHERE id=:id AND user_id=:user_id');$up->execute(['title'=>$title,'category'=>$category,'city'=>$city,'description'=>$description,'icon'=>$icon,'id'=>$id,'user_id'=>$_SESSION['user_id']]);header('Location: my_items.php?updated=1');exit;}
}
$pageTitle='Затты өңдеу';require_once 'includes/header.php';
?>
<section class="container form-page"><div class="form-card"><div class="eyebrow">QAMQOR • UPDATE</div><h1>Затты өңдеу</h1><p class="muted">Қажетті мәліметтерді өзгертіп, сақтаңыз.</p><?php if($errors): ?><div class="alert"><?php foreach($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?></div><?php endif; ?><form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>Зат атауы<input name="title" maxlength="150" required value="<?= e($title) ?>"></label><label>Санат<select name="category" required><?php foreach($categories as $c): ?><option value="<?= e($c) ?>" <?= $category===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></label><label>Қала<input name="city" maxlength="100" required value="<?= e($city) ?>"></label><label>Сипаттама<textarea name="description" rows="4" maxlength="2000"><?= e($description) ?></textarea></label><label>Белгіше<select name="icon"><?php foreach($icons as $ic): ?><option value="<?= e($ic) ?>" <?= $icon===$ic?'selected':'' ?>><?= e($ic) ?></option><?php endforeach; ?></select></label><div class="form-actions"><button class="btn btn-primary" type="submit">Өзгерістерді сақтау</button><a class="btn btn-light" href="my_items.php">Болдырмау</a></div></form></div></section>
<?php require_once 'includes/footer.php'; ?>
