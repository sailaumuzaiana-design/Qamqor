<?php
require_once 'includes/auth.php'; require_login();
require_once 'config/database.php'; require_once 'includes/csrf.php';
$errors=[]; $title=$category=$city=$description=$icon='';
$categories=['Киім','Кітап','Балалар заттары','Тұрмыстық заттар'];
$icons=['📦','🧥','📚','🧸','💡','🎒','✏️'];
if ($_SERVER['REQUEST_METHOD']==='POST') {
 verify_csrf();
 $title=trim($_POST['title']??''); $category=trim($_POST['category']??''); $city=trim($_POST['city']??''); $description=trim($_POST['description']??''); $icon=trim($_POST['icon']??'📦');
 if (mb_strlen($title)<2 || mb_strlen($title)>150) $errors[]='Зат атауы 2–150 таңба аралығында болуы керек.';
 if (!in_array($category,$categories,true)) $errors[]='Санатты таңдаңыз.';
 if (mb_strlen($city)<2 || mb_strlen($city)>100) $errors[]='Қаланы дұрыс енгізіңіз.';
 if (mb_strlen($description)>2000) $errors[]='Сипаттама 2000 таңбадан аспауы керек.';
 if (!in_array($icon,$icons,true)) $icon='📦';
 if (!$errors) {
  $stmt=$pdo->prepare('INSERT INTO items (user_id,title,category,city,description,icon) VALUES (:user_id,:title,:category,:city,:description,:icon)');
  $stmt->execute(['user_id'=>$_SESSION['user_id'],'title'=>$title,'category'=>$category,'city'=>$city,'description'=>$description,'icon'=>$icon]);
  header('Location: my_items.php?created=1'); exit;
 }
}
$pageTitle='Жаңа зат қосу'; require_once 'includes/header.php';
?>
<section class="container form-page"><div class="form-card"><div class="eyebrow">QAMQOR • CREATE</div><h1>Жаңа зат жариялау</h1><p class="muted">Басқа адамға қажет болуы мүмкін затыңызды тегін бөлісіңіз.</p>
<?php if($errors): ?><div class="alert"><?php foreach($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?></div><?php endif; ?>
<form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>Зат атауы<input name="title" maxlength="150" required value="<?= e($title) ?>" placeholder="Мысалы, қысқы күртеше"></label><label>Санат<select name="category" required><option value="">Санатты таңдаңыз</option><?php foreach($categories as $c): ?><option value="<?= e($c) ?>" <?= $category===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></label><label>Қала<input name="city" maxlength="100" required value="<?= e($city) ?>" placeholder="Алматы"></label><label>Сипаттама<textarea name="description" rows="4" maxlength="2000" placeholder="Заттың жағдайы мен ерекшелігін жазыңыз..."><?= e($description) ?></textarea></label><label>Белгіше<select name="icon"><?php foreach($icons as $ic): ?><option value="<?= e($ic) ?>" <?= $icon===$ic?'selected':'' ?>><?= e($ic) ?></option><?php endforeach; ?></select></label><div class="form-actions"><button class="btn btn-primary" type="submit">Жариялау</button><a class="btn btn-light" href="my_items.php">Болдырмау</a></div></form></div></section>
<?php require_once 'includes/footer.php'; ?>
