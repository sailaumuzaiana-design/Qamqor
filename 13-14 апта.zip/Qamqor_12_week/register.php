<?php
require_once 'includes/auth.php';
require_once 'includes/csrf.php';
require_once 'config/database.php';
$pageTitle = 'Тіркелу';
$errors = [];
$name = $email = $phone = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 verify_csrf();
 $name = trim($_POST['full_name'] ?? '');
 $email = trim($_POST['email'] ?? '');
 $phone = trim($_POST['phone'] ?? '');
 $password = $_POST['password'] ?? '';
 $confirm = $_POST['confirm_password'] ?? '';
 if ($name === '' || mb_strlen($name) < 2) $errors[] = 'Аты-жөніңізді дұрыс енгізіңіз.';
 if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Электрондық пошта форматы дұрыс емес.';
 if ($phone === '') $errors[] = 'Телефон нөмірін енгізіңіз.';
 if (strlen($password) < 8) $errors[] = 'Құпия сөз кемінде 8 таңбадан тұруы керек.';
 if ($password !== $confirm) $errors[] = 'Құпия сөздер сәйкес келмейді.';
 if (!$errors) {
  $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
  $check->execute([$email]);
  if ($check->fetch()) $errors[] = 'Бұл электрондық пошта бұрын тіркелген.';
 }
 if (!$errors) {
  $hash = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $pdo->prepare('INSERT INTO users (full_name,email,phone,password_hash,role) VALUES (?,?,?,?,?)');
  $stmt->execute([$name,$email,$phone,$hash,'user']);
  session_regenerate_id(true);
  $_SESSION['user_id'] = (int)$pdo->lastInsertId();
  $_SESSION['user_name'] = $name;
  $_SESSION['user_role'] = 'user';
  header('Location: dashboard.php'); exit;
 }
}
require_once 'includes/header.php';
?>
<section class="auth-wrap"><div class="auth-card">
 <div class="eyebrow">QAMQOR ҚАУЫМДАСТЫҒЫ</div><h1>Тіркелу</h1><p class="muted">Жақсылық жасауға арналған жаңа аккаунт құрыңыз.</p>
 <?php if ($errors): ?><div class="alert"><?php foreach($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?></div><?php endif; ?>
 <form method="post">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
  <label>Аты-жөніңіз<input name="full_name" value="<?= e($name) ?>" placeholder="Аты-жөніңізді енгізіңіз" required></label>
  <label>Электрондық пошта<input type="email" name="email" value="<?= e($email) ?>" placeholder="example@gmail.com" required></label>
  <label>Телефон нөмірі<input name="phone" value="<?= e($phone) ?>" placeholder="+7 777 123 45 67" required></label>
  <label>Құпия сөз<input type="password" name="password" placeholder="Кемінде 8 таңба" required></label>
  <label>Құпия сөзді қайталаңыз<input type="password" name="confirm_password" placeholder="Құпия сөзді қайталаңыз" required></label>
  <button class="btn btn-primary btn-wide" type="submit">Тіркелуді тексеру →</button>
 </form>
 <p class="auth-switch">Аккаунтыңыз бар ма? <a href="login.php">Жүйеге кіру</a></p>
 <p class="tiny">Тіркелу арқылы сіз платформаны пайдалану шарттарымен келісесіз.</p>
</div></section>
<?php require_once 'includes/footer.php'; ?>
