<?php
require_once 'includes/auth.php';
require_once 'config/database.php';
require_once 'includes/csrf.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { http_response_code(400); exit('Зат ID дұрыс емес.'); }
$stmt=$pdo->prepare('SELECT i.*,u.full_name,u.phone FROM items i JOIN users u ON u.id=i.user_id WHERE i.id=?');
$stmt->execute([$id]); $item=$stmt->fetch();
if(!$item){http_response_code(404);exit('Жарияланым табылмады.');}
$errors=[]; $requestMessage='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 require_login(); verify_csrf(); $action=$_POST['action']??'';
 if($action==='request_item'){
  $requestMessage=trim($_POST['message']??'');
  if((int)$item['user_id']===(int)$_SESSION['user_id']) $errors[]='Өз затыңызға өтініш бере алмайсыз.';
  elseif($item['status']!=='available') $errors[]='Бұл зат қазір қолжетімді емес.';
  elseif(mb_strlen($requestMessage)<5||mb_strlen($requestMessage)>1000) $errors[]='Өтініш мәтіні 5–1000 таңба аралығында болуы керек.';
  if(!$errors){
   try{$ins=$pdo->prepare("INSERT INTO item_requests(item_id,requester_id,message) VALUES(?,?,?)");$ins->execute([$id,$_SESSION['user_id'],$requestMessage]);header('Location: item_view.php?id='.$id.'&request_sent=1');exit;}
   catch(PDOException $e){if($e->getCode()==='23000')$errors[]='Сіз бұл затқа өтінішті бұрын жібергенсіз.';else throw $e;}
  }
 }
 if($action==='delete_comment'){
  $commentId=filter_input(INPUT_POST,'comment_id',FILTER_VALIDATE_INT);
  if(!$commentId){http_response_code(400);exit('Пікір ID дұрыс емес.');}
  if(is_admin()){$del=$pdo->prepare('DELETE FROM comments WHERE id=? AND item_id=?');$del->execute([$commentId,$id]);}
  else{$del=$pdo->prepare('DELETE FROM comments WHERE id=? AND item_id=? AND user_id=?');$del->execute([$commentId,$id,$_SESSION['user_id']]);}
  header('Location: item_view.php?id='.$id.'&comment_deleted='.($del->rowCount()?1:0).'#comments');exit;
 }
 if($action==='add_comment'){
  $comment=trim($_POST['comment']??'');
  if(mb_strlen($comment)<2||mb_strlen($comment)>1000)$errors[]='Пікір 2–1000 таңба аралығында болуы керек.';
  if(!$errors){$ins=$pdo->prepare('INSERT INTO comments(item_id,user_id,comment_text) VALUES(?,?,?)');$ins->execute([$id,$_SESSION['user_id'],$comment]);header('Location: item_view.php?id='.$id.'&comment_added=1#comments');exit;}
 }
}
$myRequest=null;
if(is_logged_in()){$r=$pdo->prepare('SELECT * FROM item_requests WHERE item_id=? AND requester_id=?');$r->execute([$id,$_SESSION['user_id']]);$myRequest=$r->fetch();}
$canSeeContact=is_logged_in()&&((int)$item['user_id']===(int)$_SESSION['user_id']||($myRequest&&in_array($myRequest['status'],['accepted','completed'],true)));
$commentsStmt=$pdo->prepare('SELECT c.id,c.user_id,c.comment_text,c.created_at,u.full_name FROM comments c JOIN users u ON u.id=c.user_id WHERE c.item_id=? ORDER BY c.created_at DESC,c.id DESC');
$commentsStmt->execute([$id]);$comments=$commentsStmt->fetchAll();
$labels=['available'=>'Қолжетімді','reserved'=>'Өтініш қабылданды — алу келісілуде','given'=>'Зат берілді'];
$pageTitle=$item['title'];require_once 'includes/header.php';
?>
<section class="container catalog-page">
 <a class="text-link" href="catalog.php">← Каталогқа қайту</a>
 <div class="detail-card"><div class="detail-art"><?= e($item['icon']) ?></div><div class="detail-content">
  <span class="tag"><?= e($item['category']) ?></span><h1><?= e($item['title']) ?></h1>
  <p class="muted">📍 <?= e($item['city']) ?> · Жариялаған: <?= e($item['full_name']) ?></p>
  <h3>Зат туралы ақпарат</h3><p class="detail-description"><?= nl2br(e($item['description']?:'Сипаттама көрсетілмеген.')) ?></p>
  <p><b class="free-label">Тегін</b> · Жарияланған күні: <?= e(date('d.m.Y',strtotime($item['created_at']))) ?></p>
  <p><b>Мәртебесі:</b> <?= e($labels[$item['status']]??'Қолжетімді') ?></p>
  <?php if($canSeeContact): ?><p>Байланыс телефоны: <b><?= e($item['phone']) ?></b></p><?php else: ?><p class="muted">Байланыс телефоны өтініш иесі қабылданғаннан кейін көрсетіледі.</p><?php endif; ?>
  <?php if(isset($_GET['request_sent'])): ?><div class="success-message">Өтінішіңіз жіберілді. Зат иесінің жауабын күтіңіз.</div><?php endif; ?>
  <?php if($errors): ?><div class="alert"><?php foreach($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?></div><?php endif; ?>
  <?php if(is_logged_in()&&(int)$item['user_id']!==(int)$_SESSION['user_id']&&$item['status']==='available'&&!$myRequest): ?>
   <form method="post" class="comment-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="request_item"><label for="request-message">Затты алуға өтініш</label><textarea id="request-message" name="message" rows="3" minlength="5" maxlength="1000" required placeholder="Неліктен бұл зат қажет екенін және оны қашан ала алатыныңызды жазыңыз..."><?= e($requestMessage) ?></textarea><button class="btn btn-primary" type="submit">Затты алуға өтініш беру</button></form>
  <?php elseif(!is_logged_in()&&$item['status']==='available'): ?><p><a class="btn btn-primary" href="login.php">Өтініш беру үшін жүйеге кіріңіз</a></p>
  <?php elseif($myRequest): ?><p class="muted">Сіздің өтінішіңіздің мәртебесі: <b><?= e(['pending'=>'Қаралуда','accepted'=>'Қабылданды','rejected'=>'Қабылданбады','completed'=>'Зат қолыңызға берілді','cancelled'=>'Бас тартылды'][$myRequest['status']]??$myRequest['status']) ?></b></p><?php endif; ?>
  <?php if(is_logged_in()&&(int)$item['user_id']===(int)$_SESSION['user_id']): ?><p><a class="btn btn-outline" href="requests.php?item_id=<?= (int)$id ?>">Осы затқа келген өтініштерді көру</a></p><?php endif; ?>
 </div></div>
 <section id="comments" class="comments-section"><h2>Пікірлер (<?= count($comments) ?>)</h2>
 <?php if(isset($_GET['comment_added'])): ?><div class="success-message">Пікіріңіз сәтті жарияланды!</div><?php endif; ?><?php if(isset($_GET['comment_deleted'])): ?><div class="success-message">Пікір өшірілді.</div><?php endif; ?>
 <?php if(is_logged_in()): ?><form method="post" class="comment-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add_comment"><label for="comment">Пікір қалдыру</label><textarea id="comment" name="comment" rows="3" maxlength="1000" required placeholder="Осы зат туралы пікіріңізді жазыңыз..."></textarea><button class="btn btn-primary" type="submit">Пікірді жариялау</button></form><?php else: ?><p>Пікір қалдыру үшін <a class="text-link" href="login.php">жүйеге кіріңіз</a>.</p><?php endif; ?>
 <?php foreach($comments as $comment): ?><article class="comment"><div class="comment-head"><b><?= e($comment['full_name']) ?></b><span class="muted"><?= e(date('d.m.Y H:i',strtotime($comment['created_at']))) ?></span></div><p><?= nl2br(e($comment['comment_text'])) ?></p><?php if(is_logged_in()&&(is_admin()||(int)$comment['user_id']===(int)$_SESSION['user_id'])): ?><form method="post" onsubmit="return confirm('Бұл пікірді өшіргіңіз келе ме?')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_comment"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><button class="btn btn-danger btn-small" type="submit">Пікірді өшіру</button></form><?php endif; ?></article><?php endforeach; ?>
 <?php if(!$comments): ?><div class="empty">Бұл затқа әлі пікір жазылмаған.</div><?php endif; ?>
 </section>
</section>
<?php require_once 'includes/footer.php'; ?>
