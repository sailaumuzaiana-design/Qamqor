</main>
<footer class="footer">
  <div class="container footer-inner">
    <a class="brand" href="index.php"><span class="brand-mark">♥</span> Qamqor</a>
    <span>Қажет емес затың — біреуге үлкен көмек</span>
  </div>
</footer>
</body>
</html>
