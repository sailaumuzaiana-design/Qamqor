<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function is_logged_in() { return isset($_SESSION['user_id']); }
function require_login() { if (!is_logged_in()) { header('Location: login.php'); exit; } }
function is_admin() { return is_logged_in() && (($_SESSION['user_role'] ?? 'user') === 'admin'); }
function require_admin() { require_login(); if (!is_admin()) { http_response_code(403); exit('Бұл бетке тек әкімші кіре алады.'); } }
