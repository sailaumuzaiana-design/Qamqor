<?php
require_once 'includes/auth.php'; require_login();
require_once 'config/database.php'; require_once 'includes/csrf.php';
$stmt=$pdo->prepare('SELECT full_name,email,phone,created_at FROM users WHERE id=:id');
$stmt->execute(['id'=>$_SESSION['user_id']]); $user=$stmt->fetch();
if(!$user){http_response_code(404);exit('Пайдаланушы табылмады.');}
$errors=[]; $name=$user['full_name']; $phone=$user['phone'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $name=trim($_POST['full_name']??''); $phone=trim($_POST['phone']??'');
 if(mb_strlen($name)<2||mb_strlen($name)>120)$errors[]='Аты-жөні 2–120 таңба аралығында болуы керек.';
 if(mb_strlen($phone)<5||mb_strlen($phone)>30)$errors[]='Телефон нөмірін дұрыс енгізіңіз.';
 if(!$errors){$up=$pdo->prepare('UPDATE users SET full_name=:name,phone=:phone WHERE id=:id');$up->execute(['name'=>$name,'phone'=>$phone,'id'=>$_SESSION['user_id']]);$_SESSION['user_name']=$name;header('Location: profile.php?updated=1');exit;}
}
$pageTitle='Менің профилім'; require_once 'includes/header.php';
?>
<section class="container form-page"><div class="form-card"><div class="eyebrow">QAMQOR • PROFILE</div><h1>Менің профилім</h1><p class="muted">Жеке мәліметтеріңізді қарап, жаңарта аласыз.</p>
<?php if(isset($_GET['updated'])): ?><div class="success-message">Профиль сәтті жаңартылды.</div><?php endif; ?>
<?php if($errors): ?><div class="alert"><?php foreach($errors as $e): ?><p><?= e($e) ?></p><?php endforeach; ?></div><?php endif; ?>
<form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>Аты-жөні<input name="full_name" value="<?= e($name) ?>" required maxlength="120"></label><label>Электрондық пошта<input value="<?= e($user['email']) ?>" disabled></label><label>Телефон нөмірі<input name="phone" value="<?= e($phone) ?>" required maxlength="30"></label><label>Тіркелген күні<input value="<?= e(date('d.m.Y',strtotime($user['created_at']))) ?>" disabled></label><button class="btn btn-primary" type="submit">Мәліметтерді сақтау</button></form></div></section>
<?php require_once 'includes/footer.php'; ?>
