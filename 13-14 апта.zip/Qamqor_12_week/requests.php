<?php
require_once 'includes/auth.php'; require_login();
require_once 'config/database.php'; require_once 'includes/csrf.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $requestId=filter_input(INPUT_POST,'request_id',FILTER_VALIDATE_INT); $action=$_POST['action']??'';
 if(!$requestId){http_response_code(400);exit('Өтініш нөмірі дұрыс емес.');}
 $pdo->beginTransaction();
 try{
  $q=$pdo->prepare('SELECT r.*,i.user_id AS owner_id,i.status AS item_status FROM item_requests r JOIN items i ON i.id=r.item_id WHERE r.id=? FOR UPDATE');$q->execute([$requestId]);$r=$q->fetch();
  if(!$r){throw new RuntimeException('Өтініш табылмады.');}
  if((int)$r['owner_id']===(int)$_SESSION['user_id']&&$action==='accept'&&$r['status']==='pending'&&$r['item_status']==='available'){
   $u=$pdo->prepare("UPDATE item_requests SET status='accepted' WHERE id=?");$u->execute([$requestId]);
   $u=$pdo->prepare("UPDATE item_requests SET status='rejected' WHERE item_id=? AND id<>? AND status='pending'");$u->execute([$r['item_id'],$requestId]);
   $u=$pdo->prepare("UPDATE items SET status='reserved' WHERE id=? AND user_id=? AND status='available'");$u->execute([$r['item_id'],$_SESSION['user_id']]);
  }elseif((int)$r['owner_id']===(int)$_SESSION['user_id']&&$action==='reject'&&$r['status']==='pending'){
   $u=$pdo->prepare("UPDATE item_requests SET status='rejected' WHERE id=?");$u->execute([$requestId]);
  }elseif((int)$r['owner_id']===(int)$_SESSION['user_id']&&$action==='complete'&&$r['status']==='accepted'&&$r['item_status']==='reserved'){
   $u=$pdo->prepare("UPDATE item_requests SET status='completed' WHERE id=?");$u->execute([$requestId]);
   $u=$pdo->prepare("UPDATE items SET status='given' WHERE id=? AND user_id=? AND status='reserved'");$u->execute([$r['item_id'],$_SESSION['user_id']]);
  }elseif((int)$r['requester_id']===(int)$_SESSION['user_id']&&$action==='cancel'&&$r['status']==='pending'){
   $u=$pdo->prepare("UPDATE item_requests SET status='cancelled' WHERE id=?");$u->execute([$requestId]);
  }else{throw new RuntimeException('Бұл әрекетті орындауға құқығыңыз жоқ немесе өтініш мәртебесі өзгерген.');}
  $pdo->commit(); header('Location: requests.php?updated=1'); exit;
 }catch(Throwable $e){$pdo->rollBack();$error=$e->getMessage();}
}
$filterItem=filter_input(INPUT_GET,'item_id',FILTER_VALIDATE_INT);
$sql="SELECT r.id,r.message,r.status,r.created_at,i.id AS item_id,i.title,u.full_name,u.phone FROM item_requests r JOIN items i ON i.id=r.item_id JOIN users u ON u.id=r.requester_id WHERE i.user_id=?";
$params=[$_SESSION['user_id']];if($filterItem){$sql.=' AND i.id=?';$params[]=$filterItem;}$sql.=' ORDER BY r.created_at DESC';$stmt=$pdo->prepare($sql);$stmt->execute($params);$incoming=$stmt->fetchAll();
$sentStmt=$pdo->prepare("SELECT r.id,r.message,r.status,r.created_at,i.id AS item_id,i.title FROM item_requests r JOIN items i ON i.id=r.item_id WHERE r.requester_id=? ORDER BY r.created_at DESC");$sentStmt->execute([$_SESSION['user_id']]);$sent=$sentStmt->fetchAll();
$labels=['pending'=>'Қаралуда','accepted'=>'Қабылданды','rejected'=>'Қабылданбады','completed'=>'Зат берілді','cancelled'=>'Бас тартылды'];
$pageTitle='Зат алуға өтініштер';require_once 'includes/header.php';
?>
<section class="container catalog-page"><div class="eyebrow">QAMQOR • REQUESTS</div><h1>Зат алуға өтініштер</h1><p class="muted">Өтінішті қабылдағаннан кейін байланыс деректері ашылады. Зат берілген соң оны «Зат берілді» деп белгілеңіз.</p>
<?php if(isset($_GET['updated'])): ?><div class="success-message">Өзгеріс сақталды.</div><?php endif; ?><?php if(!empty($error)): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
<h2>Менің заттарыма келген өтініштер</h2>
<?php if($incoming): ?><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Зат</th><th>Өтініш иесі</th><th>Хабарлама</th><th>Мәртебе</th><th>Байланыс</th><th>Әрекет</th></tr></thead><tbody><?php foreach($incoming as $r): ?><tr><td><a class="text-link" href="item_view.php?id=<?= (int)$r['item_id'] ?>"><?= e($r['title']) ?></a></td><td><?= e($r['full_name']) ?></td><td><?= e($r['message']) ?></td><td><?= e($labels[$r['status']]??$r['status']) ?></td><td><?php if(in_array($r['status'],['accepted','completed'],true)): ?><?= e($r['phone']) ?><?php else: ?>Қабылдағаннан кейін<?php endif; ?></td><td>
<?php if($r['status']==='pending'): ?><form method="post" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>"><button class="btn btn-primary btn-small" name="action" value="accept">Қабылдау</button><button class="btn btn-danger btn-small" name="action" value="reject">Бас тарту</button></form><?php elseif($r['status']==='accepted'): ?><form method="post" onsubmit="return confirm('Заттың берілгенін растайсыз ба?')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>"><button class="btn btn-primary btn-small" name="action" value="complete">Зат берілді</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty">Әзірге сіздің заттарыңызға өтініш түскен жоқ.</div><?php endif; ?>
<h2 style="margin-top:36px">Мен жіберген өтініштер</h2>
<?php if($sent): ?><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Зат</th><th>Хабарлама</th><th>Мәртебе</th><th>Әрекет</th></tr></thead><tbody><?php foreach($sent as $r): ?><tr><td><a class="text-link" href="item_view.php?id=<?= (int)$r['item_id'] ?>"><?= e($r['title']) ?></a></td><td><?= e($r['message']) ?></td><td><?= e($labels[$r['status']]??$r['status']) ?></td><td><?php if($r['status']==='pending'): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>"><button class="btn btn-light btn-small" name="action" value="cancel">Өтінішті қайтару</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty">Сіз әлі өтініш жібермедіңіз.</div><?php endif; ?>
</section><?php require_once 'includes/footer.php'; ?>
