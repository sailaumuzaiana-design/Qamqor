<?php
require_once 'includes/auth.php';
require_once 'includes/csrf.php';
require_once 'config/database.php';
$pageTitle = 'Жүйеге кіру';
$error = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 verify_csrf();
 $email = trim($_POST['email'] ?? '');
 $password = $_POST['password'] ?? '';
 if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
  $error = 'Электрондық пошта мен құпия сөзді дұрыс енгізіңіз.';
 } else {
  $stmt = $pdo->prepare('SELECT id, full_name, password_hash, role FROM users WHERE email = ? LIMIT 1');
  $stmt->execute([$email]);
  $user = $stmt->fetch();
  if ($user && password_verify($password, $user['password_hash'])) {
   session_regenerate_id(true);
   $_SESSION['user_id'] = (int)$user['id'];
   $_SESSION['user_name'] = $user['full_name'];
   $_SESSION['user_role'] = $user['role'] ?? 'user';
   header('Location: dashboard.php'); exit;
  } else $error = 'Электрондық пошта немесе құпия сөз қате.';
 }
}
require_once 'includes/header.php';
?>
<section class="auth-wrap"><div class="auth-card login-card">
 <div class="eyebrow">ҚАЙТА ҚОШ КЕЛДІҢІЗ!</div><h1>Жүйеге кіру</h1><p class="muted">Qamqor платформасына өз аккаунтыңызбен кіріңіз.</p>
 <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
 <form method="post">
  <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
  <label>Электрондық пошта<input type="email" name="email" value="<?= e($email) ?>" placeholder="example@gmail.com" required></label>
  <label>Құпия сөз<input type="password" name="password" placeholder="Құпия сөзді енгізіңіз" required></label>
  <button class="btn btn-primary btn-wide" type="submit">Кіруді тексеру →</button>
 </form>
 <p class="auth-switch">Аккаунтыңыз жоқ па? <a href="register.php">Тіркелу</a></p>
 <p class="tiny">Өзара көмек — үлкен жақсылықтың бастауы.</p>
</div></section>
<?php require_once 'includes/footer.php'; ?>
