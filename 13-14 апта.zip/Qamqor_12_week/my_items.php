<?php
require_once 'includes/auth.php'; require_login();
require_once 'config/database.php'; require_once 'includes/csrf.php';
$pageTitle = 'Менің заттарым';
$stmt = $pdo->prepare('SELECT id,title,category,city,icon,created_at,status FROM items WHERE user_id=? ORDER BY created_at DESC');
$stmt->execute([$_SESSION['user_id']]); $items=$stmt->fetchAll();
require_once 'includes/header.php';
?>
<section class="container catalog-page">
 <div class="eyebrow">ЖЕКЕ КАБИНЕТ</div>
 <div class="section-head"><div><h1>Менің жарияланымдарым</h1><p class="muted">Заттарыңызды, өтініштерді және беру мәртебесін басқарыңыз.</p></div><a class="btn btn-primary" href="item_create.php">+ Жаңа зат қосу</a></div>
 <?php if(isset($_GET['status_updated'])): ?><div class="alert alert-success">Зат берілген деп белгіленді. Ол басты бет пен каталогтан алынды.</div><?php endif; ?><?php if(isset($_GET['created'])): ?><div class="alert alert-success">Зат сәтті жарияланды.</div><?php elseif(isset($_GET['updated'])): ?><div class="alert alert-success">Өзгерістер сақталды.</div><?php elseif(isset($_GET['deleted']) && $_GET['deleted']==="1"): ?><div class="alert alert-success">Жарияланым жойылды.</div><?php endif; ?>
 <div class="results-line"><?= count($items) ?> жарияланым · <a class="text-link" href="requests.php">Өтініштерді басқару →</a></div>
 <?php if (!$items): ?><div class="empty">Сіз әлі зат жарияламадыңыз. Алғашқы затыңызды қосыңыз.</div><?php else: ?>
 <div class="item-grid">
 <?php foreach ($items as $item): $labels=['available'=>'Қолжетімді','reserved'=>'Біреуге брондалған','given'=>'Берілді']; ?>
  <article class="item-card"><div class="item-art mint"><?= e($item['icon']) ?></div><div class="item-info"><span class="tag"><?= e($item['category']) ?></span><h3><?= e($item['title']) ?></h3><p>📍 <?= e($item['city']) ?></p><p><b>Мәртебесі:</b> <?= e($labels[$item['status']] ?? 'Қолжетімді') ?></p><div class="item-foot"><a class="btn btn-outline" href="item_edit.php?id=<?= (int)$item['id'] ?>">Өңдеу</a><a class="btn btn-primary" href="requests.php?item_id=<?= (int)$item['id'] ?>">Өтініштер</a></div><?php if($item['status']==='available'): ?><form method="post" action="item_status.php" class="status-action"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><input type="hidden" name="status" value="given"><button class="btn btn-light" type="submit" onclick="return confirm('Зат берілгенін растайсыз ба?')">Зат берілді</button></form><?php endif; ?></div></article>
 <?php endforeach; ?>
 </div><?php endif; ?>
</section>
<?php require_once 'includes/footer.php'; ?>
