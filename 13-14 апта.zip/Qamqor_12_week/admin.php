<?php
require_once 'includes/auth.php'; require_admin();
require_once 'config/database.php'; require_once 'includes/csrf.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);
 if($id){$del=$pdo->prepare('DELETE FROM items WHERE id=:id');$del->execute(['id'=>$id]);}
 header('Location: admin.php?deleted=1');exit;
}
$items=$pdo->query('SELECT i.id,i.title,i.category,i.city,i.created_at,u.full_name FROM items i JOIN users u ON u.id=i.user_id ORDER BY i.created_at DESC')->fetchAll();
$pageTitle='Әкімші панелі';require_once 'includes/header.php';
?>
<section class="container catalog-page"><div class="eyebrow">QAMQOR • ADMIN</div><h1>Әкімші панелі</h1><p class="muted">Барлық жарияланымдарды басқару.</p>
<?php if(isset($_GET['deleted'])): ?><div class="success-message">Жарияланым жойылды.</div><?php endif; ?>
<?php if($items): ?><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Зат</th><th>Санат</th><th>Қала</th><th>Пайдаланушы</th><th>Әрекет</th></tr></thead><tbody><?php foreach($items as $item): ?><tr><td><a class="text-link" href="item_view.php?id=<?= (int)$item['id'] ?>"><?= e($item['title']) ?></a></td><td><?= e($item['category']) ?></td><td><?= e($item['city']) ?></td><td><?= e($item['full_name']) ?></td><td><form method="post" onsubmit="return confirm('Жарияланымды жоясыз ба?')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="btn btn-danger" type="submit">Жою</button></form></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="empty">Жарияланым жоқ.</div><?php endif; ?></section>
<?php require_once 'includes/footer.php'; ?>
