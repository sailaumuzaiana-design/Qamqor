<?php
$pageTitle = 'Заттар каталогы';
require_once 'includes/header.php';
$items = [
 ['name'=>'Жылы күртеше','category'=>'Киім','city'=>'Алматы','icon'=>'🧥','tone'=>'mint','desc'=>'Жақсы күйдегі жылы күртеше. Қыста киюге ыңғайлы.'],
 ['name'=>'Балаларға арналған кітаптар','category'=>'Кітап','city'=>'Астана','icon'=>'📚','tone'=>'sand','desc'=>'Балаларға арналған бірнеше қызықты кітап.'],
 ['name'=>'Ойыншық қонжық','category'=>'Балалар заттары','city'=>'Шымкент','icon'=>'🧸','tone'=>'blue','desc'=>'Таза, жақсы сақталған жұмсақ ойыншық.'],
 ['name'=>'Үстел шамы','category'=>'Тұрмыстық заттар','city'=>'Алматы','icon'=>'💡','tone'=>'mint','desc'=>'Оқуға арналған үстел шамы.'],
 ['name'=>'Сөмке','category'=>'Киім','city'=>'Қарағанды','icon'=>'🎒','tone'=>'sand','desc'=>'Күнделікті қолдануға арналған сөмке.'],
 ['name'=>'Оқу құралдары','category'=>'Кітап','city'=>'Тараз','icon'=>'✏️','tone'=>'blue','desc'=>'Оқушыға қажетті кеңсе заттары.'],
];
$q = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$city = trim($_GET['city'] ?? '');
$filtered = array_filter($items, function($item) use ($q,$category,$city) {
 return (!$q || mb_stripos($item['name'],$q)!==false) &&
        (!$category || $item['category']===$category) &&
        (!$city || $item['city']===$city);
});
?>
<section class="container catalog-page">
 <div class="eyebrow">ҚАМҚОРЛЫҚ КАТАЛОГЫ</div>
 <h1>Өзіңізге қажет затты табыңыз</h1>
 <p class="muted">Барлық зат тегін ұсынылады. Іздеу мен сүзгілерді пайдаланыңыз.</p>
 <form class="filter-bar" method="get" action="catalog.php">
  <label>Затты іздеу<input name="q" value="<?= e($q) ?>" placeholder="Мысалы, кітап, күртеше..."></label>
  <label>Санат<select name="category"><option value="">Барлық санаттар</option><?php foreach(['Киім','Кітап','Балалар заттары','Тұрмыстық заттар'] as $c): ?><option <?= $category===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></label>
  <label>Қала<select name="city"><option value="">Барлық қалалар</option><?php foreach(['Алматы','Астана','Шымкент','Қарағанды','Тараз'] as $c): ?><option <?= $city===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></label>
  <button class="btn btn-primary filter-btn" type="submit">Іздеу</button>
 </form>
 <div class="results-line"><?= count($filtered) ?> зат табылды <a href="catalog.php" class="text-link">Сүзгіні тазалау</a></div>
 <div class="item-grid">
 <?php foreach($filtered as $i=>$item): ?>
  <article class="item-card">
   <div class="item-art <?= e($item['tone']) ?>"><?= e($item['icon']) ?></div>
   <div class="item-info"><span class="tag"><?= e($item['category']) ?></span><h3><?= e($item['name']) ?></h3><p>📍 <?= e($item['city']) ?></p><div class="item-foot"><b>Тегін</b><button class="btn btn-outline" type="button" onclick="alert(<?= json_encode($item['desc'], JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP) ?>)">Толығырақ</button></div></div>
  </article>
 <?php endforeach; ?>
 </div>
 <?php if (!$filtered): ?><div class="empty">Іздеу бойынша зат табылмады. Сүзгілерді өзгертіп көріңіз.</div><?php endif; ?>
</section>
<?php require_once 'includes/footer.php'; ?>
