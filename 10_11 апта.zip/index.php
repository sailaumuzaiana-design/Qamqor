<?php
$pageTitle = 'Басты бет';
require_once 'includes/header.php';
?>
<section class="hero container">
  <div class="hero-copy">
    <div class="eyebrow">ҚАЙЫРЫМДЫЛЫҚ ПЕН ӨЗАРА КӨМЕК КЕҢІСТІГІ</div>
    <h1>Қажет емес затың —<br>біреуге үлкен көмек</h1>
    <p>Qamqor — адамдарды жақсылық жасауға, киім, кітап және басқа да пайдалы заттарды тегін бөлісуге біріктіретін платформа.</p>
    <div class="hero-buttons">
      <a class="btn btn-primary" href="catalog.php">Тегін заттарды қарау →</a>
      <a class="btn btn-light" href="register.php">Жақсылыққа қосылу</a>
    </div>
  </div>
  <div class="hero-art">
    <span class="art-label">♡ Бірге көмектесейік</span>
    <div class="gift">🎁</div>
    <span class="art-bottom">♧ Заттарыңды бөліс</span>
  </div>
</section>
<section class="container how">
  <div class="eyebrow">ҚАРАПАЙЫМ ҮШ ҚАДАМ</div>
  <h2>Qamqor қалай жұмыс істейді?</h2>
  <div class="steps">
    <article class="step"><span>01</span><h3>Аккаунт ашыңыз</h3><p>Платформаға тіркеліп, жақсылық жасауға қосылыңыз.</p></article>
    <article class="step"><span>02</span><h3>Затты таңдаңыз</h3><p>Каталогтан өзіңізге қажет тегін затты табыңыз.</p></article>
    <article class="step"><span>03</span><h3>Көмекке үлес қосыңыз</h3><p>Қажет емес затыңызды басқа адамдармен бөлісіңіз.</p></article>
  </div>
</section>
<section class="container preview">
  <div class="section-head"><div><div class="eyebrow">ЖАҢА ЖАРИЯЛАНЫМДАР</div><h2>Тегін берілетін заттар</h2></div><a class="text-link" href="catalog.php">Барлық заттарды көру →</a></div>
  <div class="item-grid">
    <article class="item-card"><div class="item-art mint">🧥</div><div class="item-info"><span class="tag">Киім</span><h3>Жылы күртеше</h3><p>📍 Алматы</p><div class="item-foot"><b>Тегін</b><a class="btn btn-outline" href="catalog.php">Толығырақ</a></div></div></article>
    <article class="item-card"><div class="item-art sand">📚</div><div class="item-info"><span class="tag">Кітап</span><h3>Балаларға арналған кітаптар</h3><p>📍 Астана</p><div class="item-foot"><b>Тегін</b><a class="btn btn-outline" href="catalog.php">Толығырақ</a></div></div></article>
    <article class="item-card"><div class="item-art blue">🧸</div><div class="item-info"><span class="tag">Балалар заттары</span><h3>Ойыншық қонжық</h3><p>📍 Шымкент</p><div class="item-foot"><b>Тегін</b><a class="btn btn-outline" href="catalog.php">Толығырақ</a></div></div></article>
  </div>
</section>
<section class="container cta"><div><h2>Кішкентай көмек — үлкен қуаныш</h2><p>Өзіңізге қажет емес зат басқа адамға пайдалы болуы мүмкін.</p></div><a class="btn btn-white" href="register.php">Қосылу →</a></section>
<?php require_once 'includes/footer.php'; ?>
