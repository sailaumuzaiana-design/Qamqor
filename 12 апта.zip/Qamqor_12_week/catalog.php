<?php
require_once 'config/database.php';
$pageTitle = 'Заттар каталогы';
$q=trim($_GET['q']??'');$category=trim($_GET['category']??'');$city=trim($_GET['city']??'');
$sql='SELECT i.id,i.title,i.category,i.city,i.description,i.icon,u.full_name FROM items i JOIN users u ON u.id=i.user_id WHERE 1=1';$params=[];
if($q!==''){$sql.=' AND (i.title LIKE :q_title OR i.description LIKE :q_desc)';$params['q_title']='%'.$q.'%';$params['q_desc']='%'.$q.'%';}
if($category!==''){$sql.=' AND i.category=:category';$params['category']=$category;}
if($city!==''){$sql.=' AND i.city=:city';$params['city']=$city;}
$sql.=' ORDER BY i.created_at DESC';$stmt=$pdo->prepare($sql);$stmt->execute($params);$items=$stmt->fetchAll();
require_once 'includes/header.php';
?>
<section class="container catalog-page"><div class="eyebrow">ҚАМҚОРЛЫҚ КАТАЛОГЫ</div><div class="section-head"><div><h1>Өзіңізге қажет затты табыңыз</h1><p class="muted">Пайдаланушылар жариялаған тегін заттар.</p></div><?php if(is_logged_in()): ?><a class="btn btn-primary" href="item_create.php">+ Зат қосу</a><?php endif; ?></div>
<form class="filter-bar" method="get" action="catalog.php"><label>Затты іздеу<input name="q" value="<?= e($q) ?>" placeholder="Мысалы, кітап, күртеше..."></label><label>Санат<select name="category"><option value="">Барлық санаттар</option><?php foreach(['Киім','Кітап','Балалар заттары','Тұрмыстық заттар'] as $c): ?><option value="<?= e($c) ?>" <?= $category===$c?'selected':'' ?>><?= e($c) ?></option><?php endforeach; ?></select></label><label>Қала<input name="city" value="<?= e($city) ?>" placeholder="Қала атауы"></label><button class="btn btn-primary filter-btn" type="submit">Іздеу</button></form>
<div class="results-line"><?= count($items) ?> зат табылды <a href="catalog.php" class="text-link">Сүзгіні тазалау</a></div>
<?php if($items): ?><div class="item-grid"><?php foreach($items as $item): ?><article class="item-card"><div class="item-art mint"><?= e($item['icon']) ?></div><div class="item-info"><span class="tag"><?= e($item['category']) ?></span><h3><?= e($item['title']) ?></h3><p>📍 <?= e($item['city']) ?></p><p><?= e($item['description']) ?></p><div class="item-foot"><b>Тегін</b><span class="muted"><?= e($item['full_name']) ?></span></div></div></article><?php endforeach; ?></div><?php else: ?><div class="empty">Әзірге жарияланған зат жоқ немесе іздеу бойынша нәтиже табылмады.</div><?php endif; ?>
</section><?php require_once 'includes/footer.php'; ?>
