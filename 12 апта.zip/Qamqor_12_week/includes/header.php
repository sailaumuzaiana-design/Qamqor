<?php
require_once __DIR__ . '/auth.php';
$pageTitle = $pageTitle ?? 'Qamqor';
?>
<!doctype html>
<html lang="kk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | Qamqor</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="site-header">
  <div class="nav-wrap">
    <a class="brand" href="index.php"><span class="brand-mark">♥</span> Qamqor</a>
    <nav>
      <a href="index.php">Басты бет</a>
      <a href="catalog.php">Заттар каталогы</a>
      <?php if (is_logged_in()): ?><a href="my_items.php">Менің заттарым</a><?php endif; ?>
    </nav>
    <div class="nav-actions">
      <?php if (is_logged_in()): ?>
        <a class="btn btn-light" href="dashboard.php">Профиль</a>
        <a class="btn btn-primary" href="logout.php">Шығу</a>
      <?php else: ?>
        <a class="btn btn-light" href="login.php">Кіру</a>
        <a class="btn btn-primary" href="register.php">Тіркелу</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main>
