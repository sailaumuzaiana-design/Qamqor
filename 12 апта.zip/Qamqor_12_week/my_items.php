<?php
require_once 'includes/auth.php';
require_login();
require_once 'config/database.php';
$pageTitle = 'Менің заттарым';
$stmt = $pdo->prepare('SELECT id, title, category, city, icon, created_at FROM items WHERE user_id = :user_id ORDER BY created_at DESC');
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$items = $stmt->fetchAll();
require_once 'includes/header.php';
?>
<section class="container catalog-page">
 <div class="eyebrow">ЖЕКЕ КАБИНЕТ</div>
 <div class="section-head"><div><h1>Менің жарияланымдарым</h1><p class="muted">Өзіңіз қосқан заттарды осы жерден басқара аласыз.</p></div><a class="btn btn-primary" href="item_create.php">+ Жаңа зат қосу</a></div>
 <?php if(isset($_GET['created'])): ?><div class="alert alert-success">Зат сәтті жарияланды.</div><?php elseif(isset($_GET['updated'])): ?><div class="alert alert-success">Өзгерістер сақталды.</div><?php elseif(isset($_GET['deleted']) && $_GET['deleted']==="1"): ?><div class="alert alert-success">Жарияланым жойылды.</div><?php endif; ?><div class="results-line"><?= count($items) ?> жарияланым</div>
 <?php if (!$items): ?><div class="empty">Сіз әлі зат жарияламадыңыз. Алғашқы затыңызды қосыңыз.</div><?php else: ?>
 <div class="item-grid">
 <?php foreach ($items as $item): ?>
  <article class="item-card"><div class="item-art mint"><?= e($item['icon']) ?></div><div class="item-info"><span class="tag"><?= e($item['category']) ?></span><h3><?= e($item['title']) ?></h3><p>📍 <?= e($item['city']) ?></p><div class="item-foot"><a class="btn btn-outline" href="item_edit.php?id=<?= (int)$item['id'] ?>">Өңдеу</a><form method="post" action="item_delete.php" onsubmit="return confirm('Бұл жарияланымды жоюға сенімдісіз бе?')"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="btn btn-danger" type="submit">Жою</button></form></div></div></article>
 <?php endforeach; ?>
 </div><?php endif; ?>
</section>
<?php require_once 'includes/footer.php'; ?>
